# python imports
import datetime

# django imports
from django import forms
from django.db import models
from django.template.loader import render_to_string

# portlet imports
from portlets.models import Portlet
from portlets.utils import register_portlet

# lfc imports
from lfc.models import BaseContent
from lfc.utils.registration import register_content_type
from lfc.utils.registration import register_template

class Event(BaseContent):
    """A simple event type for LFC.
    """
    start = models.DateTimeField(blank=True, default=datetime.datetime.now)
    end = models.DateTimeField(blank=True, default=datetime.datetime.now)

    def form(self, **kwargs):
        """Returns the add/edit form of the Blog
        """
        return EventForm(**kwargs)

class EventForm(forms.ModelForm):
    """Form to add / edit an Event.
    """
    class Meta:
        model = Event
        fields = ("title", "slug", "description", "start", "end")

class EventsPortlet(Portlet):
    """A simple portlet to display Events.
    """

    limit = models.IntegerField(blank=True, null=True)

    def render(self, context):
        """Renders the content of the portlet.
        """
        obj = context.get("lfc_context")
        request = context.get("request")

        events = Event.objects.restricted(request).order_by("start")[:self.limit]

        return render_to_string("lfc_events/events_portlet.html", {
            "title" : self.title,
            "events" : events,
        })

    def form(self, **kwargs):
        """Returns the add/edit form of the EventPortlet
        """
        return EventsPortletForm(instance=self, **kwargs)

class EventsPortletForm(forms.ModelForm):
    """Form to add / edit an EventPortlet.
    """
    class Meta:
        model = EventsPortlet