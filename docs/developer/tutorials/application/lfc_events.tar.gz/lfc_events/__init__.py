# lfc imports
from lfc.utils.registration import register_content_type
from lfc.utils.registration import unregister_content_type
from lfc.utils.registration import register_template
from lfc.utils.registration import unregister_template

# portlets imports
from portlets.utils import register_portlet
from portlets.utils import unregister_portlet

# lfc_events import
from lfc_events.models import Event
from lfc_events.models import EventsPortlet

name = "Events"
description = "A simple event management tool"

def install():
    
    # register templates
    register_template(name = "Event 1", path="lfc_events/event_1.html")
    register_template(name = "Event 2", path="lfc_events/event_2.html")
    
    # register content type
    register_content_type(Event, name = "Event",
        templates=["Event 1", "Event 2"], default_template="Event 1")

    # register portlet
    register_portlet(EventsPortlet, "Events")

def uninstall():
    # unregister content type
    unregister_content_type("Event")

    # unregister templates
    unregister_template("Event 1")
    unregister_template("Event 2")

    # unregister portlet
    unregister_portlet(EventsPortlet)